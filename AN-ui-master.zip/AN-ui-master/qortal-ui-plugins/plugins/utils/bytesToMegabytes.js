export function bytesToMegabytes(bytes) {
  return bytes / (1024 * 1024);
}