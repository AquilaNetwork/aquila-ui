let store
export { store }
export const initApi = (s) => { store = s }
