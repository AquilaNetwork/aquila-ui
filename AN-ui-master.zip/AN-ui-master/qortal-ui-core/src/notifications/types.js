export const NEW_MESSAGE = 'NEW_MESSAGE'
