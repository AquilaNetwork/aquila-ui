// Maybe not use redux? Login pages aren't needed all through the app?

// import { NAVIGATE_LOGIN_VIEW } from '../app-action-types.js'

// export const doAddPlugin = (epmlInstance) => {
//     // Add the appropriate routes here
//     return (dispatch, getState) => {
//         dispatch(addPlugin(epmlInstance))
//     }
// }

// const addPlugin = (payload) => {
//     return {
//         type: ADD_PLUGIN,
//         payload
//     }
// }
