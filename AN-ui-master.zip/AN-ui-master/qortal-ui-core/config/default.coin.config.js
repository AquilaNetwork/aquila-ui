const coin = {
    name: 'Qortal',
    symbol: 'QORT',
    addressCount: 1,
    addressVersion: 58,
    decimals: 100000000,
    logo: '/img/QORT_LOGO.png',
    icon: '/img/QORT_LOGO.png'
}

module.exports = coin
