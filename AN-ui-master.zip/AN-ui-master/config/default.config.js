const uiCore = require('qortal-ui-core')
const defaultConfig = uiCore('default_config')


module.exports = defaultConfig
