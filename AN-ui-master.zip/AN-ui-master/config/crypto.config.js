const defaultConfig = require('./default.config.js')

module.exports = {}
