const defaultConfig = require('./default.config.js')

module.exports = {
    name: 'Qortal',
    symbol: 'Qort',
    addressVersion: 58, // Q for Qortal
    logo: '/img/QORT_LOGO.svg'
}
