# Anyone can contribute to the project!

1) Fork the repository
2) Make changes
3) Push changes to your repository
4) Push changes to parent repository (make a pull request)

As long the code change is good we will merge it.
